from django.apps import AppConfig


class DjangoImpactConfig(AppConfig):
    name = 'django_impact'
